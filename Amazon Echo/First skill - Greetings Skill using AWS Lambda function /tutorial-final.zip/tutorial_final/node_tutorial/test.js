
var index = require('./index.js');

console.log('--------------');
var p1 = new index.Person('John','Mr. ', 'chicago');

console.log(p1.get_name());
