// Charts
windmill.chart = {};