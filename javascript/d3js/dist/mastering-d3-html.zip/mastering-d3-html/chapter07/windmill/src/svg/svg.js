
windmill.svg = {};